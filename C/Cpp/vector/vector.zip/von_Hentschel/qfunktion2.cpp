#include <iostream>
#include <iomanip>
#include <cmath>

#include "scanZahl.h"

using namespace std;

// Prototypen
double f(double x, double a, double b, double c);
double f1(double x, double a, double b);

int main(int argc, char *argv[])
{
	double a, b, c; // Die Koeffizienten

	// a != 0, sonst keine quadr. Funktion!
	do {
		if (!scanZahl("a: ", a))
			return 1; // Fehler: EOF!?!?!
	}
	while (a == 0);

	if (!scanZahl("b: ", b))
		return 1;
	if (!scanZahl("c: ", c))
		return 1;

	double xoben, xunten; // Die Grenzen der Tabelle

	if (!scanZahl("Untere Grenze: ", xunten))
		return 1;

	do {
		if (!scanZahl("Obere Grenze: ", xoben))
			return 1;
		if (xoben <= xunten)
			cout << "Muss größer als untere Grenze sein!" << endl;
	}
	while (xoben <= xunten);

	double dx; // Die Schrittweite der Tabelle

	do {
		if (!scanZahl("Schrittweite: ", dx))
			return 1;
	}
	while (dx < 1E-3 || dx > 0.5);
	
	// ================================================================================
	// Zusätzlich zur 1. Version
	// ================================================================================
	int nk; // Die Nachkommastellen in der Ausgabe

	do {
		if (!scanZahl("Nachkommastellen: ", nk))
			return 1;
	}
	while (nk < 2 || nk > 7);

	// Berechnung der Stellenanzahl (Breite) der Spalten
	int breite[3];
	double maxwert[3];

	// 1. Ermitteln der max. Werte in den Spalten (ohne Vorzeichen)
	maxwert[0] = fabs(xunten);
	maxwert[1] = fabs(f(xunten,a,b,c));
	maxwert[2] = fabs(f1(xunten,a,b));

	for (double x = xunten + dx; x <= xoben ; x += dx) {
		if (fabs(x) > maxwert[0]) maxwert[0] = fabs(x);
		if (fabs(f(x,a,b,c)) > maxwert[1]) maxwert[1] = fabs(f(x,a,b,c));
		if (fabs(f1(x,a,b)) > maxwert[2]) maxwert[2] = fabs(f1(x,a,b));
	}

	// 2. Ermitteln der Stellenanzahl vor dem Komma
	for (int sp = 0; sp < 3; sp++) {
		breite[sp] = 2 + nk; // Startwert: Nachkommastellen + Komma + Vorzeichen

		int maxw = int(maxwert[sp]); // Zahl vor dem Komma ist eine Ganzzahl!
		do {
			maxw /= 10;
			breite[sp]++;
		}
		while (maxw > 0);
	}
	// ================================================================================

	// Ausgabe Tabellenkopf!
	cout << " " << setw(breite[0]) << "x" << " | ";
	cout << setw(breite[1]) << "f(x)" << " | ";
	cout << setw(breite[2]) << "f'(x)" << endl;

	// Ausgabe einer Linie mit trennenden +-Zeichen zwischen den Spalten
	cout.fill('-');
	cout << setw(breite[0]+3) << "+";
	cout << setw(breite[1]+3) << "+";
	cout << setw(breite[2]+1) << "" << endl;
	cout.fill(' ');

	// Ausgabe-Optionen der Zahlen
	cout.setf( ios::fixed );
	cout.precision(nk);

	// Abtasten in einer Schleife von unten bis oben
	for (double x = xunten; x <= xoben ; x += dx) {
		cout << " " << setw(breite[0]) << x;
		cout << " | ";
		cout << setw(breite[1]) << f(x,a,b,c);
		cout << " | ";
		cout << setw(breite[2]) << f1(x,a,b);
		cout << endl;
	}
	return 0;
}

// Berechnet den Funktionswert f(x)
double f(double x, double a, double b, double c)
{
	return a*x*x+ b*x +c;
}

// Berechnet den Wert der 1. Ableitung von f(x)
double f1(double x, double a, double b)
{
	return 2*a*x+ b;
}
