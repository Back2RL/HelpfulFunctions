#include <iostream>
#include <iomanip>

using namespace std;

template <typename T>

// Liest einen T-Wert (template) in die Variable wert ein
// return:
//		true:  bei Erfolg
// 		false: wenn EOF erkannt wird
bool scanZahl(const char *prompt, T &wert)
{
	bool rc;

	do {
		cout << prompt;

		cin.clear();
		cin >> wert;
		if (cin.eof())
			return false;
		rc = cin.good();

		cin.clear();
		while (cin.get() != '\n')
			continue;
	}
	while(rc != true);
	return true;
}

