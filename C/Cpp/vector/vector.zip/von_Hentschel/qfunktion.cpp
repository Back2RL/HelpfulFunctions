#include <iostream>
#include <iomanip>
#include <cmath>

#include "scanZahl.h"

using namespace std;

// Prototypen
double f(double x, double a, double b, double c);
double f1(double x, double a, double b);

int main(int argc, char *argv[])
{
	double a, b, c; // Die Koeffizienten

	// a != 0, sonst keine quadr. Funktion!
	do {
		if (!scanZahl("a: ", a))
			return 1; // Fehler: EOF!?!?!
	}
	while (a == 0);

	if (!scanZahl("b: ", b))
		return 1;
	if (!scanZahl("c: ", c))
		return 1;

	double xoben, xunten; // Die Grenzen der Tabelle

	if (!scanZahl("Untere Grenze: ", xunten))
		return 1;

	do {
		if (!scanZahl("Obere Grenze: ", xoben))
			return 1;
		if (xoben <= xunten)
			cout << "Muss größer als untere Grenze sein!" << endl;
	}
	while (xoben <= xunten);

	double dx; // Die Schrittweite der Tabelle

	do {
		if (!scanZahl("Schrittweite: ", dx))
			return 1;
	}
	while (dx < 1E-3 || dx > 0.5);
	
	// Ausgabe Tabellenkopf!
	// Festes Format: 8 Zeichen Länge mit 3 Nachkommastellen
	cout << " " << setw(8) << "x" << " | ";
	cout << setw(8) << "f(x)" << " | ";
	cout << setw(8) << "f'(x)" << endl;

	// Ausgabe einer Linie mit trennenden +-Zeichen zwischen den Spalten
	cout.fill('-');
	cout << setw(8+3) << "+";
	cout << setw(8+3) << "+";
	cout << setw(8+1) << "" << endl;
	cout.fill(' ');

	// Ausgabe-Optionen der Zahlen (Format entsprechend %8.3lf in C)
	cout.setf( ios::fixed );
	cout.precision(3);

	// Abtasten in einer Schleife von unten bis oben
	for (double x = xunten; x <= xoben ; x += dx) {
		cout << " " << setw(8) << x;
		cout << " | ";
		cout << setw(8) << f(x,a,b,c);
		cout << " | ";
		cout << setw(8) << f1(x,a,b);
		cout << endl;
	}
	return 0;
}

// Berechnet den Funktionswert f(x)
double f(double x, double a, double b, double c)
{
	return a*x*x+ b*x +c;
}

// Berechnet den Wert der 1. Ableitung von f(x)
double f1(double x, double a, double b)
{
	return 2*a*x+ b;
}
