#include "Vektor.h"
#include <cmath>

// die Memberfunktionen der Klasse Vektor

// Konstruktoren (hat keinen return-Wert)
Vektor::Vektor(const double &x, const double &y, const double &z)
{
	this->x = x;
	this->y = y;
	this->z = z;
}

Vektor::Vektor(const Vektor &v) // copy-Konstruktor
{
	x = v.getX();
	y = v.getY();
	z = v.getZ();
}

double Vektor::getX(void) const
{
	return x;
}

void Vektor::setX(const double &x)
{
	this->x = x;
}
double Vektor::getY(void) const
{
	return y;
}

void Vektor::setY(const double &y)
{
	this->y = y;
}
double Vektor::getZ(void) const
{
	return z;
}

void Vektor::setZ(const double &z)
{
	this->z = z;
}

double Vektor::length(void) const
// const bedeutet: in der Memberfunktion werden keine Variablen geändert (nur Lesezugriff)
{
	return sqrt(pow(x, 2) + pow(y, 2) + pow(z, 2));
}


